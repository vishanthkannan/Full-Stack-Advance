const os = require("os");
console.log("os :",os.platform());
console.log("Type: ",os.type());
console.log("Total Memory: ",os.totalmem());
console.log("Free Memory: ",os.freemem());
console.log("Home Dir: ",os.homedir());
console.log("CPU Info: ",os.cpus());
