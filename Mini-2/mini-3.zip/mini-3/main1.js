const content = "Hello World";
const fs = require('fs');
// fs.writeFile("hello.txt","Hello World","UTF-8",(err)=>{

//     const content = "hi bro";
//     if(err)
//         console.log(err);
//     return;
// }
//     console.log(data);

// });
// fs.appendFile("hello.txt","Updated"),(err)=>{
//     if(err)
//     console.log("Error: ",err);
// return;
// }
// console.log("Data Updated");


// fs.rename("hello.txt","myfile.txt",(err)=>{
//     if(err) {
//     console.log(err);
// return;
// }
// console.log("File Renamed");
// });

// fs.unlink("myfile.txt",(err)=>{
//     if(err){
//         console.log(err);
//         return;
//     }
//     console.log("File Deleted");
// });